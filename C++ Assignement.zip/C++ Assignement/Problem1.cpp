
// Homework on Area and Circumference of circle

#include <iostream>
#include<cmath>
//#include<conio.h>
using namespace std;

// Problem 1: Write a program which allows to compute Area and circumference of a circle. (Input of the function :
//circumference)

// Area = 3.14 * radius * radius
// Circumference = 2 * 3.14 * radius

 //Solution:

  float cirumference(float D)
  {
      float Cf,pi =3.14,area;
       area =pi/2*D*D;
       cout<<"the area of circle is  "<<area<<endl;
       Cf =pi*D;
       cout<<"the cirumference of the circle is "<<Cf<<endl;
       return 0;
  }
int main()
{

   float diameter;
    cout << "Enter a radius for Area of circle!" << endl;
    cin>> diameter;

    cirumference(diameter);
    return 0;
}

